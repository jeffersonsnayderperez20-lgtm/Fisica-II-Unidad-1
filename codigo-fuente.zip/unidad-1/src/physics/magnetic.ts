import {
  type Vec,
  MU0,
  EXCLUSION,
  norm,
  dot,
  scale,
  sub,
  add,
  cross,
} from "./vector";
export type MagneticModel = "dipole" | "wire" | "loop";
export function magnetic(
  p: Vec,
  model: MagneticModel,
  current: number,
  radius: number,
  moment: number,
  segments = 160,
): Vec {
  const [x, y] = p;
  if (model === "dipole") {
    const r = norm(p);
    if (r <= 0.35)
      throw Error(
        "Interior del imán omitido: el dipolo solo modela el campo exterior.",
      );
    const m: Vec = [0, 0, moment];
    return scale(
      sub(scale(p, (3 * dot(m, p)) / r ** 5), scale(m, 1 / r ** 3)),
      MU0 / (4 * Math.PI),
    );
  }
  if (model === "wire") {
    const rho = Math.hypot(x, y);
    if (rho <= EXCLUSION) throw Error("Zona excluida junto al conductor.");
    return scale([-y, x, 0], (MU0 * current) / (2 * Math.PI * rho ** 2));
  }
  if (Math.hypot(Math.hypot(x, y) - radius, p[2]) <= EXCLUSION)
    throw Error("Zona excluida junto a la espira.");
  let B: Vec = [0, 0, 0];
  const da = (2 * Math.PI) / segments;
  for (let i = 0; i < segments; i++) {
    const a = (i + 0.5) * da,
      source: Vec = [radius * Math.cos(a), radius * Math.sin(a), 0],
      dl: Vec = [-radius * Math.sin(a) * da, radius * Math.cos(a) * da, 0];
    const r = sub(p, source);
    B = add(
      B,
      scale(cross(dl, r), (MU0 * current) / (4 * Math.PI * norm(r) ** 3)),
    );
  }
  return B;
}
