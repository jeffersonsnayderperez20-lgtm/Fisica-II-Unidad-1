import { EPS0 } from "./vector";
export function capacitor(
  A: number,
  d: number,
  er: number,
  sourceV: number,
  heldQ?: number,
) {
  if (
    ![A, d, er, sourceV].every(Number.isFinite) ||
    A <= 0 ||
    d <= 0 ||
    er < 1 ||
    (heldQ !== undefined && !Number.isFinite(heldQ))
  )
    throw Error("Usa área y separación positivas y εᵣ ≥ 1.");
  const C = (EPS0 * er * A) / d,
    V = heldQ === undefined ? sourceV : heldQ / C,
    Q = heldQ === undefined ? C * V : heldQ;
  return { C, V, Q, U: 0.5 * C * V * V, E: V / d };
}
