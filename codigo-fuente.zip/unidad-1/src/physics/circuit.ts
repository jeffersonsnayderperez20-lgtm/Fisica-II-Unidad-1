/** Bloques en serie; cada bloque contiene de 1 a 4 resistencias en paralelo.
 * Infinity representa una rama abierta, 0 una conexión ideal. */
export function parallel(rs: number[]): number {
  if (!rs.length || rs.some((r) => Number.isNaN(r) || r < 0))
    throw Error("Resistencia inválida.");
  if (rs.includes(0)) return 0;
  const g = rs.reduce((s, r) => s + 1 / r, 0);
  return g === 0 ? Infinity : 1 / g;
}
export function solveCircuit(stages: number[][], voltage: number) {
  if (!Number.isFinite(voltage) || !stages.length)
    throw Error("Fuente o circuito inválido.");
  const eq = stages.map(parallel),
    R = eq.reduce((s, r) => s + r, 0);
  if (!Number.isFinite(R))
    return { status: "open" as const, R, I: 0, P: 0, stages: [] };
  if (R === 0)
    return { status: "short" as const, R, I: null, P: null, stages: [] };
  const I = voltage / R;
  const blocks = stages.map((rs, i) => {
    const V = I * eq[i],
      zeroCount = rs.filter((r) => r === 0).length;
    return {
      R: eq[i],
      V,
      branches: rs.map((r) => {
        // Dos cables ideales en paralelo no fijan el reparto de corriente.
        const current =
          r === 0 ? (zeroCount === 1 ? I : null) : r === Infinity ? 0 : V / r;
        return {
          R: r,
          I: current,
          V,
          P: current === null ? null : V * current,
        };
      }),
    };
  });
  return { status: "ok" as const, R, I, P: voltage * I, stages: blocks };
}
