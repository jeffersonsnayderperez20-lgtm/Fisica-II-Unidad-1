import { type Vec, add, scale, cross, dot, norm, finite } from "./vector";
export interface Particle {
  position: Vec;
  velocity: Vec;
  q: number;
  m: number;
}
export type Fields = (p: Vec) => { E: Vec; B: Vec };
/** Composición simétrica: deriva media, impulso eléctrico medio, rotación Boris,
 * impulso eléctrico medio, deriva media. x y v sincronizados; orden 2. */
export function boris(
  p: Particle,
  dt: number,
  fields: Fields,
  validateSegment?: (a: Vec, b: Vec) => void,
): Particle {
  if (
    !(dt > 0 && p.m > 0) ||
    ![dt, p.m, p.q].every(Number.isFinite) ||
    !finite(p.position) ||
    !finite(p.velocity)
  )
    throw Error("Estado o paso temporal inválido.");
  const mid = add(p.position, scale(p.velocity, dt / 2)),
    { E, B } = fields(mid);
  const h = (p.q * dt) / (2 * p.m),
    minus = add(p.velocity, scale(E, h)),
    t = scale(B, h),
    s = scale(t, 2 / (1 + dot(t, t)));
  const prime = add(minus, cross(minus, t)),
    v = add(add(minus, cross(prime, s)), scale(E, h));
  const position = add(mid, scale(v, dt / 2));
  if (!finite(position) || !finite(v))
    throw Error("Desbordamiento numérico; reduce el paso temporal.");
  if (norm(v) > 0.05 * 299792458)
    throw Error(
      "Rapidez > 0,05 c: el modelo no relativista deja de ser adecuado.",
    );
  validateSegment?.(p.position, mid);
  validateSegment?.(mid, position);
  fields(position);
  return { ...p, position, velocity: v };
}
export function gyroRadius(p: Particle, B: Vec) {
  const b = norm(B);
  if (!b || !p.q) return Infinity;
  return (p.m * norm(cross(p.velocity, B))) / (Math.abs(p.q) * b * b);
}
