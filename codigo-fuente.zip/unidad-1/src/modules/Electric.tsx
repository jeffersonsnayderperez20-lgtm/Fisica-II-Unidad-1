import { useCallback, useMemo, useState } from "react";
import {
  electric,
  checkChargeSegment,
  chargeExamples,
  type Charge,
} from "../physics/electric";
import { type Vec, norm } from "../physics/vector";
import { trace, isoSurface, contours } from "../physics/geometry";
import { Scene, type SceneData } from "../components/Scene";
import {
  Num,
  VectorInput,
  Panel,
  Metric,
  Toggle,
  fmt,
} from "../components/Controls";
import { ParticleLab } from "../components/ParticleLab";
const pos = "#ff9b80",
  neg = "#78b7ff";
export function Electric() {
  const [charges, setCharges] = useState<Charge[]>(chargeExamples.Dipolo),
    [view, setView] = useState("3D"),
    [mode, setMode] = useState("Campo"),
    [probe, setProbe] = useState<Vec>([0, 1, 0]),
    [level, setLevel] = useState(8),
    [slice, setSlice] = useState(0),
    [vectors, setVectors] = useState(true),
    [lines, setLines] = useState(true),
    [surfaces, setSurfaces] = useState(true),
    [factor, setFactor] = useState(1e-9);
  const field = useCallback((p: Vec) => electric(charges, p).E, [charges]),
    potential = useCallback((p: Vec) => electric(charges, p).V, [charges]);
  const seeds = useMemo(
    () =>
      charges
        .filter((c) => c.q !== 0)
        .flatMap((c) =>
          Array.from({ length: 12 }, (_, i) => {
            const z = 1 - (2 * (i + 0.5)) / 12,
              a = i * 2.39996323,
              r = Math.sqrt(1 - z * z);
            return [
              c.position[0] + 0.15 * r * Math.cos(a),
              c.position[1] + 0.15 * r * Math.sin(a),
              c.position[2] + 0.15 * z,
            ] as Vec;
          }),
        ),
    [charges],
  );
  const data = useMemo<SceneData>(() => {
    const arrows: NonNullable<SceneData["arrows"]> = [];
    if (vectors)
      for (let x = -2.5; x <= 2.5; x += 1)
        for (let y = -2.5; y <= 2.5; y += 1)
          for (const z of [-1, 0, 1]) {
            const p: Vec = [x, y, z];
            try {
              arrows.push({
                position: p,
                direction: field(p),
                color: "#70cbbd",
              });
            } catch {}
          }
    return {
      markers: charges.map((c) => ({
        position: c.position,
        color: c.q > 0 ? pos : c.q < 0 ? neg : "#aaa",
        label: c.q > 0 ? "+" : c.q < 0 ? "−" : "0",
      })),
      arrows,
      lines: lines
        ? trace(field, seeds).map((points) => ({ points, color: "#65c4b6" }))
        : [],
      surfaces: surfaces
        ? [
            { vertices: isoSurface(potential, level), color: pos },
            { vertices: isoSurface(potential, -level), color: neg },
          ]
        : [],
    };
  }, [charges, field, potential, seeds, vectors, lines, surfaces, level]);
  const scene = useMemo<SceneData>(
    () => ({
      ...data,
      markers: [
        ...(data.markers ?? []),
        { position: probe, color: "#ffe18c", label: "P", radius: 0.07 },
      ],
    }),
    [data, probe],
  );
  const plane = useMemo(() => {
    if (view !== "2D")
      return {
        lines: [] as Vec[][],
        contours: [] as { points: Vec[]; color: string }[],
      };
    const f = (p: Vec): Vec => {
      const e = field(p);
      return [e[0], e[1], 0];
    };
    const seeds2 = Array.from(
      { length: 11 },
      (_, i) => [-2.8 + i * 0.56, -2.7, slice] as Vec,
    ).concat(
      charges.flatMap((c) =>
        Array.from(
          { length: 8 },
          (_, i) =>
            [
              c.position[0] + 0.18 * Math.cos((i * Math.PI) / 4),
              c.position[1] + 0.18 * Math.sin((i * Math.PI) / 4),
              slice,
            ] as Vec,
        ),
      ),
    );
    return {
      lines: lines ? trace(f, seeds2, 4) : [],
      contours: surfaces
        ? [
            ...contours(potential, level, slice).map((points) => ({
              points,
              color: pos,
            })),
            ...contours(potential, -level, slice).map((points) => ({
              points,
              color: neg,
            })),
          ]
        : [],
    };
  }, [view, field, potential, charges, lines, surfaces, level, slice]);
  const particleFields = useCallback(
    (p: Vec) => ({ E: field(p), B: [0, 0, 0] as Vec }),
    [field],
  );
  const checkSegment = useCallback(
    (a: Vec, b: Vec) => checkChargeSegment(charges, a, b),
    [charges],
  );
  const reset = () => {
    setCharges(chargeExamples.Dipolo);
    setProbe([0, 1, 0]);
    setLevel(8);
    setSlice(0);
    setVectors(true);
    setLines(true);
    setSurfaces(true);
    setFactor(1e-9);
  };
  const update = (id: number, change: Partial<Charge>) =>
    setCharges(charges.map((c) => (c.id === id ? { ...c, ...change } : c)));
  let measurement,
    problem = "";
  try {
    measurement = electric(charges, probe);
  } catch (e) {
    problem = (e as Error).message;
  }
  const sx = (x: number) => 360 + x * 90,
    sy = (y: number) => 270 - y * 90;
  const arrow2: { p: Vec; e: Vec }[] = [];
  if (vectors && view === "2D")
    for (let x = -3; x <= 3; x += 0.6)
      for (let y = -2.4; y <= 2.4; y += 0.6) {
        try {
          const p: Vec = [x, y, slice];
          arrow2.push({ p, e: field(p) });
        } catch {}
      }
  return (
    <>
      <div className="module-toolbar">
        <div className="segmented">
          {["Campo", "Trayectoria"].map((t) => (
            <button
              className={mode === t ? "active" : ""}
              key={t}
              onClick={() => setMode(t)}
            >
              {t}
            </button>
          ))}
        </div>
        <button onClick={reset}>Restablecer cargas</button>
      </div>
      {mode === "Trayectoria" ? (
        <ParticleLab
          externalFields={particleFields}
          background={data}
          validateSegment={checkSegment}
        />
      ) : (
        <div className="workspace">
          <Panel title="Configura el experimento" className="parameters">
            <label>
              Ejemplo
              <select
                value=""
                onChange={(e) => setCharges(chargeExamples[e.target.value])}
              >
                <option value="" disabled>
                  Seleccionar distribución
                </option>
                {Object.keys(chargeExamples).map((k) => (
                  <option key={k}>{k}</option>
                ))}
              </select>
            </label>
            <label>
              Unidad de carga
              <select
                value={factor}
                onChange={(e) => setFactor(+e.target.value)}
              >
                <option value={1e-9}>nC · nanoculombio</option>
                <option value={1e-6}>μC · microculombio</option>
              </select>
            </label>
            <div className="charges">
              {charges.map((c, i) => (
                <article className="charge-card" key={c.id}>
                  <div className="charge-title">
                    <b>
                      <i className={c.q < 0 ? "negative" : "positive"}>
                        {c.q < 0 ? "−" : "+"}
                      </i>{" "}
                      Carga {i + 1}
                    </b>
                    <button
                      aria-label={`Eliminar carga ${i + 1}`}
                      onClick={() =>
                        setCharges(charges.filter((a) => a.id !== c.id))
                      }
                    >
                      ×
                    </button>
                  </div>
                  <Num
                    label={`q${i + 1} (${factor === 1e-9 ? "nC" : "μC"})`}
                    value={c.q / factor}
                    min={-1000}
                    max={1000}
                    onChange={(v) => update(c.id, { q: v * factor })}
                  />
                  <VectorInput
                    label="Posición (m)"
                    value={c.position}
                    onChange={(p) => update(c.id, { position: p })}
                    min={-3}
                    max={3}
                  />
                </article>
              ))}
            </div>
            <button
              className="full"
              disabled={charges.length >= 10}
              onClick={() =>
                setCharges([
                  ...charges,
                  {
                    id: Math.max(0, ...charges.map((c) => c.id)) + 1,
                    q: factor,
                    position: [0, 0, 0],
                  },
                ])
              }
            >
              + Agregar carga · {charges.length}/10
            </button>
            <h3>Capas de visualización</h3>
            <Toggle
              label="Vectores del campo"
              checked={vectors}
              onChange={setVectors}
            />
            <Toggle
              label="Líneas de campo"
              checked={lines}
              onChange={setLines}
            />
            <Toggle
              label="Equipotenciales ±V"
              checked={surfaces}
              onChange={setSurfaces}
            />
            <Num
              label="Nivel |V| (voltios)"
              value={level}
              min={0.1}
              max={10000}
              onChange={setLevel}
            />
            {view === "2D" && (
              <Num
                label="Plano de corte z (m)"
                value={slice}
                min={-3}
                max={3}
                onChange={setSlice}
              />
            )}
          </Panel>
          <div className="main-column">
            <section className="visual-card">
              <div className="visual-heading">
                <span>CAMPO ELÉCTRICO</span>
                <div className="segmented dark">
                  {["2D", "3D"].map((v) => (
                    <button
                      key={v}
                      className={v === view ? "active" : ""}
                      onClick={() => setView(v)}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>
              {view === "3D" ? (
                <Scene
                  data={scene}
                  title="Campo eléctrico, cargas y superficies equipotenciales"
                />
              ) : (
                <div className="plane">
                  <svg
                    viewBox="0 0 720 540"
                    role="img"
                    aria-label="Plano XY del campo eléctrico. Pulsa para medir."
                    onClick={(e) => {
                      const r = e.currentTarget.getBoundingClientRect();
                      setProbe([
                        ((e.clientX - r.left) / r.width) * 8 - 4,
                        3 - ((e.clientY - r.top) / r.height) * 6,
                        slice,
                      ]);
                    }}
                  >
                    <defs>
                      <marker
                        id="arrowE"
                        markerWidth="4"
                        markerHeight="4"
                        refX="3"
                        refY="2"
                        orient="auto"
                      >
                        <path d="M0,0 L4,2 L0,4" fill="#65c4b6" />
                      </marker>
                    </defs>
                    {Array.from({ length: 9 }, (_, i) => (
                      <g key={i} stroke="#243b4b">
                        <line x1={i * 90} y1="0" x2={i * 90} y2="540" />
                        <line x1="0" y1={i * 90} x2="720" y2={i * 90} />
                      </g>
                    ))}
                    <g stroke="#7995aa">
                      <line x1="0" y1="270" x2="720" y2="270" />
                      <line x1="360" y1="0" x2="360" y2="540" />
                    </g>
                    {plane.contours.map((c, i) => (
                      <polyline
                        key={"c" + i}
                        points={c.points
                          .map((p) => `${sx(p[0])},${sy(p[1])}`)
                          .join(" ")}
                        stroke={c.color}
                        fill="none"
                        strokeWidth="1.5"
                      />
                    ))}
                    {plane.lines.map((p, i) => (
                      <polyline
                        key={i}
                        points={p
                          .map((a) => `${sx(a[0])},${sy(a[1])}`)
                          .join(" ")}
                        stroke="#65c4b6"
                        opacity=".6"
                        fill="none"
                      />
                    ))}
                    {arrow2.map(({ p, e }, i) => {
                      const n = Math.hypot(e[0], e[1]);
                      return n > 1e-20 ? (
                        <line
                          key={"a" + i}
                          x1={sx(p[0])}
                          y1={sy(p[1])}
                          x2={sx(p[0]) + (18 * e[0]) / n}
                          y2={sy(p[1]) - (18 * e[1]) / n}
                          stroke="#65c4b6"
                          markerEnd="url(#arrowE)"
                        />
                      ) : null;
                    })}
                    {charges.map((c) => (
                      <g key={"q" + c.id}>
                        <circle
                          cx={sx(c.position[0])}
                          cy={sy(c.position[1])}
                          r="11"
                          fill={c.q >= 0 ? pos : neg}
                          opacity={
                            Math.abs(c.position[2] - slice) < 0.1 ? 1 : 0.4
                          }
                        />
                        <text
                          x={sx(c.position[0])}
                          y={sy(c.position[1]) + 5}
                          textAnchor="middle"
                          fontWeight="bold"
                        >
                          {c.q >= 0 ? "+" : "−"}
                        </text>
                      </g>
                    ))}
                    <circle
                      cx={sx(probe[0])}
                      cy={sy(probe[1])}
                      r="6"
                      fill="#ffe18c"
                    />
                    <text x="640" y="258" fill="#b4c9d5">
                      x (m)
                    </text>
                    <text x="370" y="24" fill="#b4c9d5">
                      y (m)
                    </text>
                    <text x="12" y="526" fill="#b4c9d5">
                      Cuadrícula: 1 m · pulsa para medir · z = {slice} m
                    </text>
                  </svg>
                </div>
              )}
              <div className="legend">
                <span className="positive-text">● +q / +V</span>
                <span className="negative-text">● −q / −V</span>
                <span>↗ E normalizado</span>
                <span>● P: punto de medida</span>
              </div>
            </section>
            <Panel title="Explora y compara">
              <p>
                Modifica el signo de una carga y observa cómo cambia el campo.
                En el centro del dipolo, ¿el potencial puede ser cero aunque el
                campo no lo sea?
              </p>
              <div className="formula">
                E(r) = k Σ qᵢ (r − rᵢ) / |r − rᵢ|³
                <br />
                V(r) = k Σ qᵢ / |r − rᵢ|
              </div>
              <small>
                Flechas de longitud fija: indican dirección, no magnitud.
                Superficies calculadas en [−3, 3] m con malla de 32³ celdas.
                Pueden desaparecer si el nivel está fuera del dominio.
              </small>
            </Panel>
          </div>
          <Panel title="Medición en un punto" className="results">
            <VectorInput
              label="Punto P (m)"
              value={probe}
              onChange={setProbe}
              min={-10}
              max={10}
            />
            {problem ? (
              <p role="alert" className="error-box">
                {problem}
              </p>
            ) : (
              measurement && (
                <>
                  <Metric
                    label="Magnitud del campo |E|"
                    value={norm(measurement.E)}
                    unit="N/C"
                  />
                  <Metric label="Potencial V" value={measurement.V} unit="V" />
                  <p>
                    Eₓ, Eᵧ, E𝓏 (N/C):
                    <br />
                    {measurement.E.map((v) => fmt(v)).join("; ")}
                  </p>
                </>
              )
            )}
            <h3>Cómo leer la escena</h3>
            <p>
              El campo sale de cargas positivas y entra en negativas. El
              potencial se suma como escalar, con referencia cero en el
              infinito.
            </p>
            <p>
              El radio dibujado es simbólico. Se excluyen 0,08 m alrededor de
              las cargas; no se suaviza la ley de Coulomb.
            </p>
            <p>
              En 2D se muestra un corte z constante y la proyección XY del
              campo. Si las cargas están fuera del plano, sus líneas proyectadas
              no son las líneas espaciales completas; las cargas se ven
              atenuadas.
            </p>
            <small>
              Las fuentes permanecen fijas. Las líneas son trazos numéricos, no
              trayectorias de partículas.
            </small>
          </Panel>
        </div>
      )}
    </>
  );
}
