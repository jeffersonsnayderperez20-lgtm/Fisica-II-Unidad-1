import { useEffect, useId, useState, type ReactNode } from "react";
import type { Vec } from "../physics/vector";
export function Num({
  label,
  value,
  onChange,
  min = -1e9,
  max = 1e9,
  step = "any",
  disabled = false,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  step?: number | "any";
  disabled?: boolean;
}) {
  const id = useId(),
    [text, setText] = useState(String(value));
  useEffect(() => setText(String(Number(value.toPrecision(12)))), [value]);
  const n = Number(text),
    bad = text.trim() === "" || !Number.isFinite(n) || n < min || n > max;
  return (
    <label className="number" htmlFor={id}>
      <span>{label}</span>
      <input
        id={id}
        type="number"
        value={text}
        min={min}
        max={max}
        step={step}
        disabled={disabled}
        aria-invalid={bad}
        onBlur={() => {
          if (bad) setText(String(value));
        }}
        onChange={(e) => {
          setText(e.target.value);
          const v = e.target.valueAsNumber;
          if (Number.isFinite(v) && v >= min && v <= max) onChange(v);
        }}
      />
      {bad && (
        <small className="error">
          No aplicado: usa {min} a {max}. Se conserva el último valor válido.
        </small>
      )}
    </label>
  );
}
export function VectorInput({
  label,
  value,
  onChange,
  factor = 1,
  min = -100,
  max = 100,
}: {
  label: string;
  value: Vec;
  onChange: (v: Vec) => void;
  factor?: number;
  min?: number;
  max?: number;
}) {
  return (
    <fieldset>
      <legend>{label}</legend>
      <div className="vector-input">
        {["x", "y", "z"].map((axis, i) => (
          <Num
            key={axis}
            label={axis}
            value={value[i] / factor}
            min={min}
            max={max}
            onChange={(n) =>
              onChange(value.map((v, j) => (j === i ? n * factor : v)) as Vec)
            }
          />
        ))}
      </div>
    </fieldset>
  );
}
export const fmt = (v: number, unit = "") =>
  `${Number.isFinite(v) ? (v === 0 ? "0" : Math.abs(v) >= 0.001 && Math.abs(v) < 1e5 ? v.toLocaleString("es-PE", { maximumSignificantDigits: 5 }) : v.toExponential(4)) : "—"}${unit ? " " + unit : ""}`;
export function Metric({
  label,
  value,
  unit = "",
}: {
  label: string;
  value: number;
  unit?: string;
}) {
  return (
    <div className="metric">
      <span>{label}</span>
      <strong>{fmt(value, unit)}</strong>
    </div>
  );
}
export function Panel({
  title,
  children,
  className = "",
}: {
  title: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`panel ${className}`}>
      <h2>{title}</h2>
      {children}
    </section>
  );
}
export function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="toggle">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
      />
      {label}
    </label>
  );
}
