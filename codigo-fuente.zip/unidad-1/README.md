# CampoLab - Código fuente de la unidad 1

Aplicación de electricidad, campo eléctrico y potencial. Incluye interfaz React/TypeScript, visualización Three.js, motor físico y pruebas.

## Requisitos y ejecución

Node.js 22.12 o superior. En esta carpeta:

```bash
npm install
npm run dev
```

Abrir la dirección indicada por Vite. Para instalar con el bloqueo incluido: `pnpm install --frozen-lockfile` (pnpm 11.19.0).

## Comandos

- `npm test`: pruebas del motor físico de la unidad 1.
- `npm run build`: comprobar TypeScript y generar dist.
- `npm run preview`: servir la compilación después del build.

## Estructura

- src/modules/Electric.tsx: controles de la unidad 1.
- src/components: componentes y visualización.
- src/physics: biblioteca física compartida, conservada para resolver sus dependencias internas.
- tests: validación numérica y casos límite.

Esta entrega solo contiene fuentes y archivos de desarrollo. El informe y el manual se entregan por separado. Los enlaces a esos documentos se han retirado de esta edición para evitar enlaces rotos.
