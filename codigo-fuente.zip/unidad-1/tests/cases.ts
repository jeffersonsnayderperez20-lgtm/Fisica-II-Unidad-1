import { electric } from "../src/physics/electric";
import { capacitor } from "../src/physics/capacitor";
import { solveCircuit } from "../src/physics/circuit";
import { boris, type Particle } from "../src/physics/particle";
import { magnetic } from "../src/physics/magnetic";
import { isoSurface, contours } from "../src/physics/geometry";
import { K, MU0, norm, sub, type Vec } from "../src/physics/vector";
export interface Check {
  name: string;
  error: number;
  tolerance: number;
  unit: string;
  detail: string;
}
export function runChecks(): Check[] {
  const out: Check[] = [],
    check = (
      name: string,
      error: number,
      tolerance: number,
      unit: string,
      detail: string,
    ) => out.push({ name, error: Math.abs(error), tolerance, unit, detail });
  const f = electric([{ id: 1, q: 1e-9, position: [0, 0, 0] }], [2, 0, 0]);
  check(
    "Campo de una carga puntual",
    f.E[0] / ((K * 1e-9) / 4) - 1,
    1e-12,
    "relativo",
    "q = 1 nC; r = 2 m; E = kq/r².",
  );
  check(
    "Potencial de una carga puntual",
    f.V / ((K * 1e-9) / 2) - 1,
    1e-12,
    "relativo",
    "V = kq/r.",
  );
  const pair = electric(
    [
      { id: 1, q: 1e-9, position: [-1, 0, 0] },
      { id: 2, q: -1e-9, position: [1, 0, 0] },
    ],
    [0, 0, 0],
  );
  check(
    "Superposición de dos cargas",
    norm(sub(pair.E, [2 * K * 1e-9, 0, 0])) / (2 * K * 1e-9),
    1e-12,
    "relativo",
    "Dipolo: los campos se suman en el centro.",
  );
  check(
    "Potencial nulo del dipolo",
    pair.V,
    1e-12,
    "V",
    "Centro: V = 0 aunque E ≠ 0.",
  );
  const cap = capacitor(0.02, 0.002, 2, 12);
  check(
    "Capacitancia ideal",
    cap.C / 1.77083756256e-10 - 1,
    1e-12,
    "relativo",
    "A = 0,02 m²; d = 0,002 m; εr = 2.",
  );
  check(
    "Energía del capacitor",
    cap.U / 1.2750030450432e-8 - 1,
    1e-12,
    "relativo",
    "V = 12 V; U = ½CV².",
  );
  const isolated = capacitor(0.02, 0.002, 4, 12, cap.Q);
  check(
    "Carga conservada al desconectar",
    isolated.Q / cap.Q - 1,
    1e-12,
    "relativo",
    "Se duplica εr a Q constante.",
  );
  check(
    "Voltaje a carga constante",
    isolated.V / 6 - 1,
    1e-12,
    "relativo",
    "Al duplicar εr, V se reduce a 6 V.",
  );
  for (const [name, stages, expected] of [
    ["Serie", [[100], [200], [300]], 600],
    ["Paralelo", [[100, 200]], 200 / 3],
    ["Mixto", [[100], [200, 300], [50]], 270],
  ] as [string, number[][], number][]) {
    check(
      `Resistencia equivalente ${name}`,
      solveCircuit(stages, 12).R / expected - 1,
      1e-12,
      "relativo",
      "Red con solución analítica.",
    );
  }
  const circuit = solveCircuit([[100], [200, 300], [50]], 12);
  if (circuit.status === "ok") {
    check(
      "Kirchhoff de corrientes",
      Math.max(
        ...circuit.stages.map((s) =>
          Math.abs(s.branches.reduce((a, b) => a + (b.I ?? 0), 0) - circuit.I!),
        ),
      ),
      1e-12,
      "A",
      "Σ I de ramas = I total en cada bloque.",
    );
    check(
      "Kirchhoff de voltajes",
      circuit.stages.reduce((a, s) => a + s.V, 0) - 12,
      1e-12,
      "V",
      "Σ V de bloques = V de fuente.",
    );
    check(
      "Balance de potencia",
      circuit.stages
        .flatMap((s) => s.branches)
        .reduce((a, b) => a + (b.P ?? 0), 0) - circuit.P!,
      1e-12,
      "W",
      "La potencia entregada coincide con la disipación.",
    );
  }
  check(
    "Conductor rectilíneo",
    magnetic([2, 0, 0], "wire", 10, 1, 1)[1] / ((MU0 * 10) / (4 * Math.PI)) - 1,
    1e-12,
    "relativo",
    "I = 10 A; ρ = 2 m.",
  );
  check(
    "Espira sobre su eje",
    magnetic([0, 0, 0.8], "loop", 10, 1, 1)[2] /
      ((MU0 * 10) / (2 * (1 + 0.8 ** 2) ** 1.5)) -
      1,
    1e-12,
    "relativo",
    "Solución axial de radio 1 m; cuadratura 160 segmentos.",
  );
  const fineB = magnetic([0.4, 0.2, 0.3], "loop", 10, 1, 1, 2560),
    coarseB = magnetic([0.4, 0.2, 0.3], "loop", 10, 1, 1, 160);
  check(
    "Convergencia espacial de Biot–Savart",
    norm(sub(coarseB, fineB)) / norm(fineB),
    1e-6,
    "relativo",
    "160 frente a 2560 segmentos; punto fuera de la zona excluida.",
  );
  const p: Particle = {
      q: 1e-6,
      m: 1e-9,
      position: [0, 0, 0],
      velocity: [1, 0, 0],
    },
    fields = () => ({ E: [0, 0, 0] as Vec, B: [0, 0, 0.001] as Vec });
  let s = p,
    maxSpeed = 0,
    maxRadius = 0;
  for (let i = 0; i < 10000; i++) {
    s = boris(s, 0.01, fields);
    maxSpeed = Math.max(maxSpeed, Math.abs(norm(s.velocity) - 1));
    maxRadius = Math.max(
      maxRadius,
      Math.abs(Math.hypot(s.position[0], s.position[1] + 1) - 1),
    );
  }
  check(
    "Rapidez conservada con E = 0",
    maxSpeed,
    1e-10,
    "relativo",
    "10000 pasos Δt = 0,01 s; campo magnético puro.",
  );
  check(
    "Radio de giro r = mv⊥ / |q|B",
    maxRadius,
    1e-10,
    "m",
    "Radio teórico 1 m; distancia al centro (0,−1,0) durante 10000 pasos.",
  );
  const advance = (dt: number) => {
    let a = p;
    for (let i = 0; i < Math.round(2 / dt); i++) a = boris(a, dt, fields);
    return norm(sub(a.position, [Math.sin(2), Math.cos(2) - 1, 0]));
  };
  const e1 = advance(0.04),
    e2 = advance(0.02);
  check(
    "Error de posición Δt = 0,04 s",
    e1,
    3e-4,
    "m",
    "Comparación con x = sin t, y = cos t − 1 en t = 2 s.",
  );
  check(
    "Error de posición Δt = 0,02 s",
    e2,
    8e-5,
    "m",
    "Mismo tiempo físico, paso dividido por dos.",
  );
  check(
    "Orden de convergencia de Boris",
    Math.abs(e1 / e2 - 4),
    0.02,
    "diferencia respecto a 4",
    "El cociente de errores debe aproximarse a 4 (orden 2).",
  );
  const coulomb = (dt: number) => {
    let a: Particle = { q: 1, m: 1, position: [1, 0, 0], velocity: [0, 1, 0] };
    for (let i = 0; i < Math.round(1 / dt); i++)
      a = boris(a, dt, (x) => ({
        E: electric([{ id: 1, q: -1 / K, position: [0, 0, 0] }], x).E,
        B: [0, 0, 0],
      }));
    return norm(sub(a.position, [Math.cos(1), Math.sin(1), 0]));
  };
  check(
    "Convergencia en campo no uniforme",
    Math.abs(coulomb(0.04) / coulomb(0.02) - 4),
    0.04,
    "diferencia respecto a 4",
    "Órbita circular de Coulomb; comparación analítica en t = 1 s.",
  );
  let a: Particle = { q: 1, m: 1, position: [0, 0, 0], velocity: [0, 0, 0] };
  for (let i = 0; i < 100; i++)
    a = boris(a, 0.01, () => ({ E: [2, 0, 0], B: [0, 0, 0] }));
  check(
    "Aceleración eléctrica uniforme",
    norm(sub(a.position, [1, 0, 0])),
    1e-12,
    "m",
    "x = ½at²; a = 2 m/s²; t = 1 s.",
  );
  const potential = (x: Vec) =>
    electric([{ id: 1, q: 1e-9, position: [0, 0, 0] }], x).V;
  const vertices = isoSurface(potential, K * 1e-9),
    radial = [];
  for (let i = 0; i < vertices.length; i += 3)
    radial.push(
      Math.abs(Math.hypot(vertices[i], vertices[i + 1], vertices[i + 2]) - 1),
    );
  check(
    "Superficie equipotencial esférica",
    Math.max(...radial),
    0.04,
    "m",
    "Nivel k·1 nC: radio esperado 1 m; malla 32³.",
  );
  const curves = contours(potential, K * 1e-9);
  check(
    "Curva equipotencial circular",
    Math.max(...curves.flatMap((l) => l.map((p) => Math.abs(norm(p) - 1)))),
    0.01,
    "m",
    "Plano z = 0; malla 65².",
  );
  return out.filter(c => ["Campo de una carga puntual", "Potencial de una carga puntual", "Superposición de dos cargas", "Potencial nulo del dipolo", "Convergencia en campo no uniforme", "Aceleración eléctrica uniforme", "Superficie equipotencial esférica", "Curva equipotencial circular"].includes(c.name));
}
