import { describe, it, expect } from "vitest";
import { runChecks } from "./cases";
import { electric, checkChargeSegment } from "../src/physics/electric";
import { capacitor } from "../src/physics/capacitor";
import { solveCircuit } from "../src/physics/circuit";
import { magnetic } from "../src/physics/magnetic";
import { boris } from "../src/physics/particle";
describe("Validación física y numérica", () => {
  for (const c of runChecks())
    it(c.name, () => expect(c.error).toBeLessThanOrEqual(c.tolerance));
});
describe("Casos límite del alcance", () => {
  it("detecta cruce de esfera excluida entre extremos válidos", () =>
    expect(() =>
      checkChargeSegment(
        [{ id: 1, q: 1e-9, position: [0, 0, 0] }],
        [-1, 0, 0],
        [1, 0, 0],
      ),
    ).toThrow());
  it("rechaza singularidad de Coulomb", () =>
    expect(() =>
      electric([{ id: 1, q: 1e-9, position: [0, 0, 0] }], [0, 0, 0]),
    ).toThrow());
  it("cargas cero no generan singularidad ficticia", () =>
    expect(electric([{ id: 1, q: 0, position: [0, 0, 0] }], [0, 0, 0]).V).toBe(
      0,
    ));
  it("rechaza masa nula", () =>
    expect(() =>
      boris(
        { q: 1, m: 0, position: [0, 0, 0], velocity: [1, 0, 0] },
        0.01,
        () => ({ E: [0, 0, 0], B: [0, 0, 1] }),
      ),
    ).toThrow());
});
